const router = require('express').Router();
let Trace = require('../models/sensorTrace.model');

// Get all Traces:
router.route('/').get((req, res) => {
    Trace.find()
    .then(traces => res.json(traces))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Specific Trace:
router.route('/:id').get((req, res) => {
    Trace.findById(req.params.id)
    .then(trace => res.json(trace))
    .catch(err => res.status(400).json('Error: ' + err));
});

// Add Trace:
router.route('/add').post((req, res) => {
    const sensorId = req.body.sensorId;
    const action = req.body.action;
    const newTrace = new Trace({
      sensorId,
      action,
    });
    newTrace.save()
      .then(() => res.json('Trace added!'))
      .catch(err => res.status(400).json('Error: ' + err));
  });

module.exports = router;