import React from 'react';
import Floor0 from '../images/buildingPlans/floor.svg';

const Floor0_plan = () => {
    return (
        <div>
            <img height='700px' src={ Floor0 } alt='floor 0 svg' />
        </div>
    )
}

export default Floor0_plan
