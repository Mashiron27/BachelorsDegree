import React from 'react';
import Floor2 from '../images/buildingPlans/floor.svg';

const Floor2_plan = () => {
    return (
        <div>
            <img height='700px' src={ Floor2 } alt='floor 2 svg' />
        </div>
    )
}

export default Floor2_plan
