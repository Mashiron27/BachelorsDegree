import React from 'react';
import Floor3 from '../images/buildingPlans/floor.svg';

const Floor3_plan = () => {
    return (
        <div>
            <img height='700px' src={ Floor3 } alt='floor 3 svg' />
        </div>
    )
}

export default Floor3_plan
