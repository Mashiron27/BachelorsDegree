import React from 'react';
import Floor4 from '../images/buildingPlans/floor.svg';

const Floor4_plan = () => {
    return (
        <div>
            <img height='700px' src={ Floor4 } alt='floor 4 svg' />
        </div>
    )
}

export default Floor4_plan
