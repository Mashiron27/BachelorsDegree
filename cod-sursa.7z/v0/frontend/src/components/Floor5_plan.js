import React from 'react';
import Floor5 from '../images/buildingPlans/floor.svg';

const Floor5_plan = () => {
    return (
        <div>
            <img height='700px' src={ Floor5 } alt='floor 5 svg' />
        </div>
    )
}

export default Floor5_plan
