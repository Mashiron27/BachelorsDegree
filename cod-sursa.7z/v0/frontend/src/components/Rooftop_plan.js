import React from 'react';
import Rooftop from '../images/buildingPlans/roof.png';

const Rooftop_plan = () => {
    return (
        <div>
            <img height='700px' src={ Rooftop } alt='rooftop svg' />
        </div>
    )
}

export default Rooftop_plan
