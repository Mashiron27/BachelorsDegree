import React, { Component } from 'react';
import axios from 'axios';
import '../../App.css';

import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory, { PaginationProvider } from 'react-bootstrap-table2-paginator';
 

const columns = [{
    dataField: 'severity',
    text: 'Severity'
  }, {
    dataField: 'description',
    text: 'Description'
  }];


const paginationOption = (legth) =>({
    custom: true,
    totalSize: legth,
    sizePerPage: 25
    
})

const Notification = props => (
    <tr>
        <td>{ props.notification.severity }</td>
        <td>{ props.notification.description }</td>
    </tr>
)


const NotifiList = props => (
  <li>
      {props.notification.description}   
  </li>
)

export class NotifListShow extends Component{
   constructor(props) {
    super(props);

    this.state = { notifications: [] }
  }

  componentDidMount() {
    axios.get('http://localhost:5000/notifications/')
        .then(response => {
            this.setState({ notifications: response.data })
        })
        .catch((error) => {
            console.log(error);
        })
  }

  notificationList() {
    return this.state.notifications.filter((currentnotification,idx) => idx < 7).map(currentnotification => {
      return <NotifiList notification={ currentnotification } />
        
    })
  }
  
  render() {
    return this.notificationList()
  }
}


export default class NotificationList extends Component {

    constructor(props) {
        super(props);

        this.state = { notifications: [] }
    }

    componentDidMount() {
        axios.get('http://localhost:5000/notifications/')
            .then(response => {
                this.setState({ notifications: response.data })
            })
            .catch((error) => {
                console.log(error);
            })
    }

    notificationList() {
        return this.state.notifications.map(currentnotification => {
            return <Notification notification={ currentnotification } />
        })
    }


    handleNextPage = ({
        page,
        onPageChange
      }) => () => {
        if (page === 1) {
            onPageChange(page + 1);
        }else
        {
            onPageChange(page);
        }
       
      }
    
      handlePrevPage = ({
        page,
        onPageChange
      }) => () => {
        if (page != 1) {
            onPageChange(page - 1);
        }else
        {
            onPageChange(page);
        }
       
      }
    
      handleSizePerPage = ({
        page,
        onSizePerPageChange
      }, newSizePerPage) => {
        onSizePerPageChange(newSizePerPage, page);
      }

    
    render() {
        console.log(this.state.notifications.length);
        return (
            
            <div className="notif-list">
                
               
               
                <PaginationProvider
          pagination={ paginationFactory(paginationOption(this.state.notifications.length)) }
        >
          {
            ({
              paginationProps,
              paginationTableProps
            }) => (
              <div style={{ height: "80vh"}}>                                
                <div className="btn-group" role="group">                
                  <button className="btn btn-success" onClick={ this.handlePrevPage(paginationProps) }>Prev Page</button>
                  <button className="btn btn-primary" onClick={ this.handleNextPage(paginationProps) }>Next Page</button>   
                  
                </div>  
                <div>
                  <p>Current Page: { paginationProps.page }</p>                 
                </div> 
                <BootstrapTable
                  keyField="id"
                  data={ this.state.notifications }
                  columns={ columns }
                  { ...paginationTableProps }
                />                                            
               
              </div>
            )
          }
        </PaginationProvider>
              
             
            </div>
        )
    }
}