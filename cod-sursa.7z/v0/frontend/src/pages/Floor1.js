import React from 'react';
import FloorSVG from '../components/FloorSVG';
import '../components/FloorSVG.css';
import SensorList, {SensorListShow} from '../components/data/SensorList'; 

const Floor1 = () => {
	
    return (
        <div style={{overflow: "hidden"}}>
         	
			<div className="info-panel">
				<span id="InfoTitle">Informatii</span>
				<SensorListShow />
			</div>
           {/* <FloorSVG senzor1id="senzor" senzor1="red" senzor2="green" camera1="green" camera2="green" />*/}
			<SensorList/>
			
        </div>
    )
}

export default Floor1
