import React from 'react';
import Floor2_plan from '../components/Floor2_plan';
import '../components/FloorSVG.css';
import SensorList, {SensorListShow} from '../components/data/SensorList'; 

const Floor2 = () => {
    return (
        <div style={{overflow: "hidden"}}>
         	
        <div className="info-panel">
            <span id="InfoTitle">Informatii</span>
            <SensorListShow />
        </div>
       {/* <FloorSVG senzor1id="senzor" senzor1="red" senzor2="green" camera1="green" camera2="green" />*/}
        <SensorList/>
        
    </div>
    )
}

export default Floor2
