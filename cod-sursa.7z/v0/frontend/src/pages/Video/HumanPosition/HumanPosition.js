import React from 'react'

const HumanPosition = () => {
    return (
        <div>
            HumanPosition
        </div>
    )
}

export default HumanPosition
